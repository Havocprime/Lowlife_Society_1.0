from __future__ import annotations
import os, discord
from discord import app_commands
from dotenv import load_dotenv

from src.core.rules import load_rules, load_templates
from src.core.embeds import build_combat_embed

load_dotenv()
TOKEN = os.getenv("DISCORD_TOKEN")
if not TOKEN:
    raise SystemExit("Missing DISCORD_TOKEN in environment")

intents = discord.Intents.default()
client = discord.Client(intents=intents)
tree = app_commands.CommandTree(client)

@client.event
async def on_ready():
    try:
        guild_id = os.getenv("GUILD_ID")
        if guild_id:
            await tree.sync(guild=discord.Object(id=int(guild_id)))
            print(f"Synced commands to guild {guild_id}")
        else:
            await tree.sync()
            print("Synced commands globally")
    except Exception as e:
        print("Slash command sync error:", e)
    print(f"Lowlife bot online as {client.user}")

@tree.command(name="ping", description="Check if the Lowlife bot is alive")
async def ping(interaction: discord.Interaction):
    await interaction.response.send_message("pong 🫡")

@tree.command(name="mock_round", description="Render a full combat round using rules & templates")
async def mock_round(interaction: discord.Interaction):
    _ = load_rules()   # not used in this simple mock, but verifies file loads
    templates = load_templates()
    tpl = templates["combat_log"]
    attacker, defender = "ChromeJack", "Bricks"
    before, after = "Mid", "Near"
    round_summary = (
        "**Round 2**\n"
        f"• {attacker} fires *9mm Pistol* at **{before}** — **HIT** (82%) → **8 dmg** to {defender}\n"
        f"• Status applied: **Bleed (2 turns)** on {defender}\n"
        f"• {defender} (AI) not in melee range → **Advance** to **{after}**\n"
        f"• End: Bleed tick deals **2** more to {defender}; Range is now **{after}**"
    )
    statuses = f"{defender}: Bleed (2t) • Range: {before}→{after}\n{attacker}: —"
    payload = build_combat_embed(
        tpl, attacker=attacker, defender=defender, range_state=before,
        round_summary=round_summary, hp_a=(50,50), hp_b=(40,50), statuses=statuses
    )
    embed = discord.Embed(title=payload["title"], description=payload["description"])
    for fld in payload["fields"]:
        embed.add_field(name=fld["name"], value=fld["value"], inline=fld["inline"])
    await interaction.response.send_message(embed=embed)

if __name__ == "__main__":
    client.run(TOKEN)
