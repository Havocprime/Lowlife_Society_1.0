from __future__ import annotations
from typing import Dict, Any

def hp_bar(cur: int, maxv: int, width: int = 20) -> str:
    cur = max(0, min(cur, maxv))
    ratio = cur / maxv if maxv > 0 else 0
    filled = int(round(ratio * width))
    return "█" * filled + "░" * (width - filled) + f" ({cur}/{maxv})"

def build_combat_embed(tpl: Dict[str, Any], *, attacker: str, defender: str, range_state: str,
                       round_summary: str, hp_a: tuple[int,int], hp_b: tuple[int,int], statuses: str) -> Dict[str, Any]:
    return {
        "title": tpl["title"].format(attacker=attacker, defender=defender, range_state=range_state),
        "color": tpl["color"],
        "description": round_summary,
        "fields": [
            {"name": f"{attacker} HP", "value": hp_bar(*hp_a), "inline": True},
            {"name": f"{defender} HP", "value": hp_bar(*hp_b), "inline": True},
            {"name": "Statuses", "value": statuses, "inline": False},
        ],
    }
